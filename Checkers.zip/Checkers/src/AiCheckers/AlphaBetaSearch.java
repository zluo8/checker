package AiCheckers;

import java.util.List;

public class AlphaBetaSearch extends AdversarialSearch {
    private CheckersMove makeDecision(CheckersData state, List<CheckersMove> legalMoves, int depth){
        if(legalMoves.size()==1){
            return legalMoves.get(0);
        }
        double resultValue = Double.NEGATIVE_INFINITY;
        int player = CheckersData.BLACK;
        CheckersMove result = null;

        for (CheckersMove action : legalMoves) {
            CheckersData clonedCheckersData = state.clone();
            clonedCheckersData.makeMove(action);
            double value = minValue(clonedCheckersData, state.getCounterPlayer(player), resultValue, Double.POSITIVE_INFINITY,depth-1);
            if (value > resultValue) {
                result = action;
                resultValue = value;
            }
        }
        return result;
    }

    public double maxValue(CheckersData state, int player, double alpha, double beta,int depth) {
        if(state.isGameTerminal(player,depth)){
            return evaluateBoardUtility(state, player);
        }
        double value = Double.NEGATIVE_INFINITY;
        for (CheckersMove action : state.getLegalMoves(player)) {
            CheckersData clonedCheckersData = state.clone();
            clonedCheckersData.makeMove(action);
            value = Math.max(value, minValue(
                    clonedCheckersData,
                    state.getCounterPlayer(player),
                    alpha,
                    beta,
                    depth-1
            ));
            if (value >= beta) {
                return value;
            }
            alpha = Math.max(alpha, value);
        }
        return value;
    }

    public double minValue(CheckersData state, int player, double alpha, double beta, int depth) {
        if(state.isGameTerminal(player,depth)){
            return evaluateBoardUtility(state,player);
        }
        double value = Double.POSITIVE_INFINITY;
        for (CheckersMove action : state.getLegalMoves(player)) {
            CheckersData clonedCheckersData = state.clone();
            clonedCheckersData.makeMove(action);
            value = Math.min(value, maxValue(
                    clonedCheckersData,
                    state.getCounterPlayer(player),
                    alpha,
                    beta,
                    depth-1
            ));
            if (value <= alpha) {
                return value;
            }
            beta = Math.min(beta, value);
        }
        return value;
    }

    @Override
    public CheckersMove makeMove(List<CheckersMove> legalMoves) {
        System.out.println(board);
        System.out.println();
        int depth = 5;
        CheckersData checkersData = this.board.clone();
        return makeDecision(checkersData,legalMoves,depth);
    }
}
