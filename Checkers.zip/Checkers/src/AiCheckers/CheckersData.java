package AiCheckers;

import java.util.ArrayList;
import java.util.List;

/**
 * An object of this class holds data about a game of checkers.
 * It knows what kind of piece is on each square of the checkerboard.
 * Note that RED moves "up" the board (i.e. row number decreases)
 * while BLACK moves "down" the board (i.e. row number increases).
 * Methods are provided to return lists of available legal moves.
 */
public class CheckersData {

  /*  The following constants represent the possible contents of a square
      on the board.  The constants RED and BLACK also represent players
      in the game. */

    static final int
            EMPTY = 0,
            RED = 1,
            RED_KING = 2,
            BLACK = 3,
            BLACK_KING = 4,
            SIZE = 8;


    int[][] board;  // board[r][c] is the contents of row r, column c.


    /**
     * Constructor.  Create the board and set it up for a new game.
     */
    CheckersData() {
        board = new int[SIZE][SIZE];
        setUpGame();
    }

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_YELLOW = "\u001B[33m";

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < board.length; i++) {
            int[] row = board[i];
            sb.append(SIZE - i).append(" ");
            for (int n : row) {
                if (n == 0) {
                    sb.append(" ");
                } else if (n == 1) {
                    sb.append(ANSI_RED + "R" + ANSI_RESET);
                } else if (n == 2) {
                    sb.append(ANSI_RED + "K" + ANSI_RESET);
                } else if (n == 3) {
                    sb.append(ANSI_YELLOW + "B" + ANSI_RESET);
                } else if (n == 4) {
                    sb.append(ANSI_YELLOW + "K" + ANSI_RESET);
                }
                sb.append(" ");
            }
            sb.append(System.lineSeparator());
        }
        sb.append("  a b c d e f g h");

        return sb.toString();
    }

    /**
     * Set up the board with checkers in position for the beginning
     * of a game.  Note that checkers can only be found in squares
     * that satisfy  row % 2 == col % 2.  At the start of the game,
     * all such squares in the first three rows contain black squares
     * and all such squares in the last three rows contain red squares.
     */
    void setUpGame() {
        // TODO
    	//
        for(int i=0;i<3;++i){
            for(int j=0;j<SIZE;++j){
                if((i%2) != (j%2)){
                    board[i][j]=BLACK;
                }else{
                    board[i][j]=0;
                }
            }
        }
        for(int i=3;i<=4;++i){
            for(int j=0;j<SIZE;++j){
                board[i][j]=0;
            }
        }
        for(int i=5;i<SIZE;++i){
            for(int j=0;j<SIZE;++j){
                if((i%2) != (j%2)){
                    board[i][j]=RED;
                }else{
                    board[i][j]=0;
                }
            }
        }
    	// Set up the board with pieces BLACK, RED, and EMPTY
    }


    /**
     * Return the contents of the square in the specified row and column.
     */
    int pieceAt(int row, int col) {return board[row][col];}


    /**
     */
    void makeMove(CheckersMove move) {
        int l = move.rows.size();
        for(int i = 0; i < l-1; i++) {
            makeMove(move.rows.get(i), move.cols.get(i), move.rows.get(i+1), move.cols.get(i+1));
        }
    }

    /**
     * @param fromRow row index of the from square
     * @param fromCol column index of the from square
     * @param toRow   row index of the to square
     * @param toCol   column index of the to square
     */
    void makeMove(int fromRow, int fromCol, int toRow, int toCol) {
        if((Math.abs(toRow-fromRow)==2)&&(Math.abs(toCol-fromCol)==2)){
            board[(fromRow+toRow)/2][(fromCol+toCol)/2]=0;
        }
        if(isBlackTurningKing(toRow, toCol, fromRow, fromCol)){
            board[toRow][toCol] = 4;
        }
        else if(isRedTurningKing(toRow, toCol, fromRow, fromCol)) {
            board[toRow][toCol] = 2;
        }
        else{
            board[toRow][toCol] = board[fromRow][fromCol];
        }
        board[fromRow][fromCol] = 0;
    }

    private boolean isBlackTurningKing(int toRow, int toCol, int fromRow, int fromCol){
        return ((board[fromRow][fromCol]==3)&&(toRow==7));
    }

    private boolean isRedTurningKing(int toRow, int toCol, int fromRow, int fromCol){
        return ((board[fromRow][fromCol]==1)&&(toRow==0));
    }

    /**
     *
     * @param player color of the player, RED or BLACK
     */
    List<CheckersMove> getLegalMoves(int player) {
        // TODO
        ArrayList<Integer> rowPlayerCells = new ArrayList<>();
        ArrayList<Integer> colPlayerCells = new ArrayList<>();
        ArrayList<Integer> rowPlayerCellsKing = new ArrayList<>();
        ArrayList<Integer> colPlayerCellsKing = new ArrayList<>();
        int[][] boardClone = board.clone();
        for(int i=0;i<SIZE;++i){
            for(int j=0;j<SIZE;++j){
                if(boardClone[i][j]==player){
                    rowPlayerCells.add(i);
                    colPlayerCells.add(j);
                }else if(boardClone[i][j]==(player+1)){
                    rowPlayerCellsKing.add(i);
                    colPlayerCellsKing.add(j);
                }
            }
        }

        List<CheckersMove> listOfJumpMoves = getListOfJumpMoves(rowPlayerCells, colPlayerCells, rowPlayerCellsKing, colPlayerCellsKing, boardClone, player);
        if(listOfJumpMoves.isEmpty()){
            boardClone = board.clone();
            return getListOfNormalMoves(rowPlayerCells, colPlayerCells, rowPlayerCellsKing, colPlayerCellsKing, boardClone, player);
        }
        return listOfJumpMoves;
    }

    List<CheckersMove> getListOfJumpMoves(ArrayList<Integer> rowCells, ArrayList<Integer> colCells, ArrayList<Integer> rowCellsKing,
                                          ArrayList<Integer> colCellsKing, int board[][], int player){
        List<CheckersMove> listOfCheckersMoves = new ArrayList<>();
        for(int i=0;i<rowCells.size();++i){
            int rowCell = rowCells.get(i);
            int colCell = colCells.get(i);
            if(player==CheckersData.RED){
                if(isEmpty(rowCell-2,colCell+2)&&isBlack(rowCell-1,colCell+1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForPiece(rowCell,colCell,rowCell-2,colCell+2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
                if(isEmpty(rowCell-2,colCell-2)&&isBlack(rowCell-1,colCell-1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForPiece(rowCell,colCell,rowCell-2,colCell-2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
            }
            if(player==CheckersData.BLACK){
                if(isEmpty(rowCell+2,colCell+2)&&isRed(rowCell+1,colCell+1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForPiece(rowCell,colCell,rowCell+2,colCell+2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
                if(isEmpty(rowCell+2,colCell-2)&&isRed(rowCell+1,colCell-1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForPiece(rowCell,colCell,rowCell+2,colCell-2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
            }
        }
        for(int i=0;i<rowCellsKing.size();++i){
            int rowCell = rowCellsKing.get(i);
            int colCell = colCellsKing.get(i);
            if(player==CheckersData.RED){
                if(isEmpty(rowCell-2,colCell+2)&&isBlack(rowCell-1,colCell+1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForKing(rowCell,colCell,rowCell-2,colCell+2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
                if(isEmpty(rowCell-2,colCell-2)&&isBlack(rowCell-1,colCell-1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForKing(rowCell,colCell,rowCell-2,colCell-2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
                if(isEmpty(rowCell+2,colCell+2)&&isBlack(rowCell+1,colCell+1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForKing(rowCell,colCell,rowCell+2,colCell+2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
                if(isEmpty(rowCell+2,colCell-2)&&isBlack(rowCell+1,colCell-1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForKing(rowCell,colCell,rowCell+2,colCell-2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
            }
            if(player==CheckersData.BLACK){
                if(isEmpty(rowCell-2,colCell+2)&&isRed(rowCell-1,colCell+1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForKing(rowCell,colCell,rowCell-2,colCell+2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
                if(isEmpty(rowCell-2,colCell-2)&&isRed(rowCell-1,colCell-1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForKing(rowCell,colCell,rowCell-2,colCell-2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
                if(isEmpty(rowCell+2,colCell+2)&&isRed(rowCell+1,colCell+1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForKing(rowCell,colCell,rowCell+2,colCell+2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
                if(isEmpty(rowCell+2,colCell-2)&&isRed(rowCell+1,colCell-1)){
                    List<CheckersMove> checkersMove= calculateAllJumpSequencesForKing(rowCell,colCell,rowCell+2,colCell-2);
                    listOfCheckersMoves.addAll(checkersMove);
                }
            }
        }
        return listOfCheckersMoves;
    }

    List<CheckersMove> getListOfNormalMoves(ArrayList<Integer> rowCells, ArrayList<Integer> colCells, ArrayList<Integer> roCellsKing,
                                            ArrayList<Integer> colCellsKing, int board[][], int player){
        List<CheckersMove> moves = new ArrayList<>();
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                if (board[row][col] == player) {
                    // Check forward moves
                    if (player == CheckersData.RED) {
                        if (isEmpty(row-1,col+1)) {
                            moves.add(new CheckersMove(row, col, row-1, col+1));
                        }
                        if (isEmpty(row-1,col-1)) {
                            moves.add(new CheckersMove(row, col, row-1, col-1));
                        }
                    }

                    // Check backward moves
                    if (player == CheckersData.BLACK) {
                        if (isEmpty(row+1,col+1)) {
                            moves.add(new CheckersMove(row, col, row+1, col+1));
                        }
                        if (isEmpty(row+1,col-1)) {
                            moves.add(new CheckersMove(row, col, row+1, col-1));
                        }
                    }
                }
            }
        }
        //King moves
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                if (board[row][col] == (player+1)) {
                    if (isEmpty(row-1,col+1)) {
                        moves.add(new CheckersMove(row, col, row-1, col+1));
                    }
                    if (isEmpty(row-1,col-1)) {
                        moves.add(new CheckersMove(row, col, row-1, col-1));
                    }
                    if (isEmpty(row+1,col+1)) {
                        moves.add(new CheckersMove(row, col, row+1, col+1));
                    }
                    if (isEmpty(row+1,col-1)) {
                        moves.add(new CheckersMove(row, col, row+1, col-1));
                    }
                }
            }
        }
        return moves;
    }

    private boolean isEmpty(int row, int col){
        return isValid(row,col)&&(board[row][col]==0);
    }

    private boolean isBlack(int row, int col){
        return isValid(row,col)&&((board[row][col]==CheckersData.BLACK)||(board[row][col]==CheckersData.BLACK_KING));
    }

    private boolean isRed(int row, int col){
        return isValid(row,col)&&((board[row][col]==CheckersData.RED)||(board[row][col]==CheckersData.RED_KING));
    }

    private boolean isValid(int row, int col){
        return (row>=0)&(row<=7)&&(col>=0)&&(col<=7);
    }

    private List<CheckersMove> calculateAllJumpSequencesForPiece(int startRowCell, int startColCell, int firstJumpRowCell, int firstJumpColCell){
        CheckersMove checkersMove = new CheckersMove();
        checkersMove.addMove(startRowCell,startColCell);
        checkersMove.addMove(firstJumpRowCell,firstJumpColCell);
        List<CheckersMove> listOfPossibleEndStates = new ArrayList<>();
        int player = board[startRowCell][startColCell];
        exploreJumpsForNormalPiece(player,startRowCell,startColCell,firstJumpRowCell,firstJumpColCell,listOfPossibleEndStates,checkersMove);
        return listOfPossibleEndStates;
    }

    private List<CheckersMove> calculateAllJumpSequencesForKing(int startRowCell, int startColCell, int firstJumpRowCell, int firstJumpColCell){
        CheckersMove checkersMove = new CheckersMove();
        checkersMove.addMove(startRowCell,startColCell);
        checkersMove.addMove(firstJumpRowCell,firstJumpColCell);
        List<CheckersMove> listOfPossibleEndStates = new ArrayList<>();
        int player = board[startRowCell][startColCell];
        exploreJumpsForKingPiece(player,startRowCell,startColCell,firstJumpRowCell,firstJumpColCell,listOfPossibleEndStates,checkersMove);
        return listOfPossibleEndStates;
    }

    void exploreJumpsForNormalPiece(int player, int pRow, int pCol, int row, int col, List<CheckersMove> listOfMoves, CheckersMove checkersMove){
        if(player==CheckersData.RED){
            int countOfJumpsMade = 0;
            if(isBlack(row-1,col-1)&isEmpty(row-2,col-2)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row-2,col-2);
                exploreJumpsForNormalPiece(player, row,col,row-2,col-2,listOfMoves,checkersMoveJump);
            }
            if(isBlack(row-1,col+1)&isEmpty(row-2,col+2)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row-2,col+2);
                exploreJumpsForNormalPiece(player, row,col,row-2,col+2,listOfMoves,checkersMoveJump);
            }
            if(countOfJumpsMade==0){
                listOfMoves.add(checkersMove);
            }
        }
        else if(player==CheckersData.BLACK){
            int countOfJumpsMade=0;
            if(isRed(row+1,col-1)&isEmpty(row+2,col-2)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row+2,col-2);
                exploreJumpsForNormalPiece(player, row,col,row+2,col-2,listOfMoves,checkersMoveJump);
            }
            if(isRed(row+1,col+1)&isEmpty(row+2,col+2)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row+2,col+2);
                exploreJumpsForNormalPiece(player, row,col,row+2,col+2,listOfMoves,checkersMoveJump);
            }
            if(countOfJumpsMade==0){
                listOfMoves.add(checkersMove);
            }
        }
    }

    void exploreJumpsForKingPiece(int player, int pRow, int pCol, int row, int col, List<CheckersMove> listOfMoves, CheckersMove checkersMove){
        if(player==CheckersData.RED_KING){
            int countOfJumpsMade = 0;
            if(isBlack(row-1,col-1)&isEmpty(row-2,col-2)&&notParent(row-2,col-2,pRow,pCol)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row-2,col-2);
                exploreJumpsForKingPiece(player, row,col,row-2,col-2,listOfMoves,checkersMoveJump);
            }
            if(isBlack(row-1,col+1)&isEmpty(row-2,col+2)&&notParent(row-2,col+2,pRow,pCol)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row-2,col+2);
                exploreJumpsForKingPiece(player, row,col,row-2,col+2,listOfMoves,checkersMoveJump);
            }
            if(isBlack(row+1,col-1)&isEmpty(row+2,col-2)&&notParent(row+2,col-2,pRow,pCol)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row+2,col-2);
                exploreJumpsForKingPiece(player, row,col,row+2,col-2,listOfMoves,checkersMoveJump);
            }
            if(isBlack(row+1,col+1)&isEmpty(row+2,col+2)&&notParent(row+2,col+2,pRow,pCol)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row+2,col+2);
                exploreJumpsForKingPiece(player, row,col,row+2,col+2,listOfMoves,checkersMoveJump);
            }
            if(countOfJumpsMade==0){
                listOfMoves.add(checkersMove);
            }
        }
        else if(player==CheckersData.BLACK_KING){
            int countOfJumpsMade = 0;
            if(isRed(row-1,col-1)&isEmpty(row-2,col-2)&&notParent(row-2,col-2,pRow,pCol)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row-2,col-2);
                exploreJumpsForKingPiece(player, row,col,row-2,col-2,listOfMoves,checkersMoveJump);
            }
            if(isRed(row-1,col+1)&isEmpty(row-2,col+2)&&notParent(row-2,col+2,pRow,pCol)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row-2,col+2);
                exploreJumpsForKingPiece(player, row,col,row-2,col+2,listOfMoves,checkersMoveJump);
            }
            if(isRed(row+1,col-1)&isEmpty(row+2,col-2)&&notParent(row+2,col-2,pRow,pCol)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row+2,col-2);
                exploreJumpsForKingPiece(player, row,col,row+2,col-2,listOfMoves,checkersMoveJump);
            }
            if(isRed(row+1,col+1)&isEmpty(row+2,col+2)&&notParent(row+2,col+2,pRow,pCol)){
                ++countOfJumpsMade;
                CheckersMove checkersMoveJump = checkersMove.clone();
                checkersMoveJump.addMove(row+2,col+2);
                exploreJumpsForKingPiece(player, row,col,row+2,col+2,listOfMoves,checkersMoveJump);
            }
            if(countOfJumpsMade==0){
                listOfMoves.add(checkersMove);
            }
        }
    }
    private boolean notParent(int nextRow, int nextCol, int pRow, int pCol){
        return (nextRow!=pRow)||(nextCol!=pCol);
    }


    @Override
    public CheckersData clone() {
        CheckersData newBoard = new CheckersData();
        for(int i=0; i<this.board.length;i++) {
            System.arraycopy(this.board[i], 0, newBoard.board[i], 0, SIZE);
        }
        return newBoard;

    }

    public boolean isGameTerminal(int player, int depth) {
        if (depth == 0) {
            return true;
        }
        int countRedPieces = countPlayerPieces(CheckersData.RED);
        int countBlackPieces = countPlayerPieces(CheckersData.BLACK);

        if (countRedPieces == 0 || countBlackPieces == 0) {
            return true;
        }

        if (getLegalMoves(player).isEmpty()) {
            return true;
        }
        return false;
    }

    private int countPlayerPieces(int playerColor) {
        int count = 0;
        for (int i = 0; i < 8; ++i) {
            for (int j = 0; j < 8; ++j) {
                if (board[i][j] == playerColor || board[i][j] == (playerColor + 1)) {
                    ++count;
                }
            }
        }
        return count;
    }

    public int getCounterPlayer(int player) {
        return (player == CheckersData.RED) ? CheckersData.BLACK :
                (player == CheckersData.BLACK) ? CheckersData.RED : 0;
    }
}