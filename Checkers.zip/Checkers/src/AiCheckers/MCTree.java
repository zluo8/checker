package AiCheckers;

public class MCTree
{
	MCNode root;
	int size;

	public static boolean treeConstructed;

	MCTree(MCNode root, int size){

	}
}
