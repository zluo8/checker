package AiCheckers;

import java.util.List;

/**
 * Node type for the Monte Carlo search tree.
 */
public class MCNode
{
    private CheckersData state;
    private MCNode parent;
    private List<MCNode> children;

    private CheckersMove actionOnParent;
    private double visitCount;

    private double numberOfWins;
    private double utilityScore;

    private int player;

    public int currentResult;

    public MCNode(CheckersData state, int player, CheckersMove actionOnParent) {
        this.state = state;
        this.parent = null;
        this.children = null;
        this.visitCount = 0;
        this.utilityScore = 0;
        this.player = player;
        this.actionOnParent = actionOnParent;
    }

    public CheckersData getState() {
        return state;
    }

    public MCNode getParent() {
        return parent;
    }

    public int getPlayer() {
        return player;
    }

    public List<MCNode> getChildren() {
        return children;
    }

    public void addChildren(List<MCNode> children) {
        this.children = children;
    }
    public void incrementVisitCount() {
        this.visitCount++;
    }
    public void incrementWinCount() {
        this.numberOfWins++;
    }

    public void incrementDrawCount() {
        this.numberOfWins+=0.5;
    }

    public double calculateUCTValue() {
        if (this.parent == null) {
            return this.numberOfWins / this.visitCount;
        }

        double winRatio = this.numberOfWins / this.visitCount;
        double explorationFactor = Math.sqrt(2);
        double logParentVisits = Math.log(this.parent.visitCount);
        double explorationTerm = explorationFactor * Math.sqrt(logParentVisits / this.visitCount);

        return winRatio + explorationTerm;
    }

    public CheckersMove getActionOnParent() {
        return actionOnParent;
    }

    public MCNode selectBestChildByUCT(MCNode parentNode){
        double highestUCTValue = -1;
        MCNode result = parentNode.getChildren().get(0);
        for(MCNode child:parentNode.getChildren()){
            double uctValue  = child.calculateUCTValue();
            if(uctValue  > highestUCTValue){
                result = child;
                highestUCTValue = uctValue ;
            }
        }
        return result;
    }
}

