package AiCheckers;

/**
 * 
 * @author 
 *
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

/**
 * This class implements the Monte Carlo tree search method to find the best
 * move at the current state.
 */
public class MonteCarloTreeSearch extends AdversarialSearch {

    public static int depthLimit;

    public static int numberOfGames;

    public static int simulationDepth;

    private MCTree mcTree;

    MonteCarloTreeSearch(){
        depthLimit = 12;
    }

	/**
     * The input parameter legalMoves contains all the possible moves.
     * It contains four integers:  fromRow, fromCol, toRow, toCol
     * which represents a move from (fromRow, fromCol) to (toRow, toCol).
     * It also provides a utility method `isJump` to see whether this
     * move is a jump or a simple move.
     *
     * Each legalMove in the input now contains a single move
     * or a sequence of jumps: (rows[0], cols[0]) -> (rows[1], cols[1]) ->
     * (rows[2], cols[2]).
     *
     * @param legalMoves All the legal moves for the agent at current step.
     */


    @Override
    public CheckersMove makeMove(List<CheckersMove> legalMoves) {
        System.out.println(board);
        System.out.println();
        return bestMoveAsPerMonteCarloSearch(legalMoves);
    }


    private CheckersMove bestMoveAsPerMonteCarloSearch(List<CheckersMove> legalMoves){
        depthLimit = 3;
        numberOfGames = 3;
        simulationDepth = 3;
        boolean flag=false;
        CheckersData checkersDataCloned = this.board.clone();
        MCNode root = new MCNode(checkersDataCloned,CheckersData.BLACK, null);
        mcTree = constructTreeOfDepth(depthLimit,root);
        mcTree.root = root;
        while (numberOfGames != 0) {
            MCNode leaf = select(mcTree, depthLimit);
            int simulatedChildResult = (int) expandAndSimulate(leaf,simulationDepth);
            backpropagate(simulatedChildResult, leaf, leaf.getPlayer());
            --numberOfGames;
        }
        return bestAction(mcTree.root);
    }

    private MCNode select(MCTree mcTree, int depthLimit) {
        MCNode node = mcTree.root;
        while ((!node.getState().isGameTerminal(CheckersData.BLACK,depthLimit)) && Objects.nonNull(node.getChildren())) {
            node = node.selectBestChildByUCT(node);
        }
        return node;
    }

    MCTree constructTreeOfDepth(int depthLimit, MCNode root){
        CheckersData checkersDataCurrent = this.board.clone();
        List<MCNode> children = new ArrayList<>();
        for(CheckersMove action: checkersDataCurrent.getLegalMoves(CheckersData.BLACK)){
            children.add(generateNodeWithChildren(checkersDataCurrent,root,depthLimit-1,action));
        }
        root.addChildren(children);
        return new MCTree(root, depthLimit);
    }

    private MCNode generateNodeWithChildren(CheckersData board, MCNode parent, int depthLimit, CheckersMove actionOnParent){
        if(depthLimit<=0){
            return null;
        }
        CheckersData boardClone = board.clone();
        boardClone.makeMove(actionOnParent);
        int currentPlayer = boardClone.getCounterPlayer(parent.getPlayer());
        MCNode node = new MCNode(boardClone, currentPlayer, actionOnParent);
        List<MCNode> children = new ArrayList<>();
        for(CheckersMove action: boardClone.getLegalMoves(currentPlayer)){
            MCNode child = generateNodeWithChildren(boardClone,node,depthLimit-1,action);
            if(Objects.nonNull(child)){children.add(child);}
        }
        if(!children.isEmpty()){node.addChildren(children);}
        return node;
    }

    private double expandAndSimulate(MCNode currentNode, int depth) {
        if(currentNode.getState().isGameTerminal(CheckersData.BLACK,depth)) {
            currentNode.currentResult = (int) evaluateBoardUtility(currentNode.getState(),currentNode.getPlayer());
            return evaluateBoardUtility(currentNode.getState(),currentNode.getPlayer());
        }
        Random rand = new Random();
        List<CheckersMove> legalMovesList = currentNode.getState().getLegalMoves(currentNode.getPlayer());
        CheckersMove checkersMoveRandom = legalMovesList.get(rand.nextInt(legalMovesList.size()));
        CheckersData checkersDataCloned = currentNode.getState().clone();
        int player = currentNode.getState().getCounterPlayer(currentNode.getPlayer());
        checkersDataCloned.makeMove(checkersMoveRandom);
        MCNode node = new MCNode(checkersDataCloned,player, checkersMoveRandom);
        return expandAndSimulate(node,depth-1);
    }

    private void backpropagate(int result, MCNode node, int player) {
        node.incrementVisitCount();
        if(result>0){
            if(node.getPlayer()==player){
                node.incrementWinCount();
            }
        }
        if(result==0){
            node.incrementDrawCount();
        }
        if (node.getParent() != null) {
            backpropagate(result, node.getParent(),player);
        }
    }

    private CheckersMove bestAction(MCNode root) {
        MCNode bestChild = root.selectBestChildByUCT(root);
        return bestChild.getActionOnParent();
    }
}
