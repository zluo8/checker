package AiCheckers;


import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import java.util.*;
//Scanner for the external input.
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Checkers extends JPanel {
	//AIKEY
	static int aiKey = 0;

    public static void main(String[] args) {
		System.out.println("A Checker-Playing Agent");
		// 1: use alpha-beta pruning throughout the game.
		// 2: use Monte Carlo tree search throughout the game.
		// 3: randomly choose between alpha-beta and MCTS to decide on the next move. 
		System.out.println("keys: 1 (alpha-beta)  2 (MCTS)  3 (random)\n");
        JFrame window = new JFrame("Checkers");

        Checkers content = new Checkers();
        window.setContentPane(content);
        
        window.pack();
        Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
        window.setLocation( (screensize.width - window.getWidth())/2,
                (screensize.height - window.getHeight())/2 );
        window.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        window.setResizable(false);
        window.setVisible(true);
    }

    private JButton newGameButton;  // Button for starting a new game.
    private JButton resignButton;   // Button that a player can use to end
    // the game by resigning.

    private JLabel message;  // Label for displaying messages to the user.
    private static JLabel premessage;
    
    //Previous display
    static PreBoard previous = new PreBoard(); // Display previous board

    public Checkers() {
        setLayout(null);
        setPreferredSize( new Dimension(550,250) );
        setBackground(new Color(0,150,0));  // Dark green background.


        Board board = new Board();  // Note: The constructor for the
        add(board);
        add(previous);
        
        add(newGameButton);
        add(resignButton);
        add(message);
        add(premessage);

        //board.setBounds(20,20,164,164); // Note:  size MUST be 164-by-164 !
        previous.setBounds(20,20,164,164);
        board.setBounds(230,20,164,164);

        //previous.setBounds(20,20,164,164);
        newGameButton.setBounds(400, 60, 120, 30);
        resignButton.setBounds(400, 120, 120, 30);
        message.setBounds(140, 200, 350, 30);
        premessage.setBounds(40, 200, 350, 30);
    }

    public static class PreBoard extends JPanel{
    	CheckersData preBoard;
    	CheckersMove moveAI;
    	PreBoard()
    	{
    		premessage = new JLabel("",JLabel.LEFT);
    		premessage.setFont(new  Font("Serif", Font.BOLD, 14));
    		premessage.setForeground(Color.green);
            premessage.setText("Initialization");
            preBoard = new CheckersData();
            preBoard.setUpGame();
            moveAI = new CheckersMove();
            repaint();
    	}
    	public void drawBoard(CheckersData currentBoard, CheckersMove move)
    	{
    		premessage = new JLabel("",JLabel.LEFT);
    		premessage.setFont(new  Font("Serif", Font.BOLD, 14));
    		premessage.setForeground(Color.green);
    		premessage.setText("Agent to Play");
    		preBoard = copyBoard(currentBoard);
    		moveAI = move.clone();
    		repaint();
    	}
    	private CheckersData copyBoard(CheckersData board)
        {
            this.preBoard = board;
            CheckersData new_board = new CheckersData();
            for(int i=0; i<board.board.length;i++)
            {
                for(int j=0;j<8;j++)
                {
                    new_board.board[i][j]=board.pieceAt(i, j);
                }
            }
            return new_board;
        }
    	
    	@Override
        public void paintComponent(Graphics g) {
            /* Draw a two-pixel black border around the edges of the canvas. */
            g.setColor(Color.black);
            g.drawRect(0,0,getSize().width-1,getSize().height-1);
            g.drawRect(1,1,getSize().width-3,getSize().height-3);
            /* Draw the squares of the checkerboard and the checkers. */
            for (int row = 0; row < 8; row++) {
                for (int col = 0; col < 8; col++) {
                    if ( row % 2 == col % 2 ) {
                        g.setColor(Color.LIGHT_GRAY);
                    } else {
                        g.setColor(Color.GRAY);
                    }
                    g.fillRect(2 + col*20, 2 + row*20, 20, 20);
                    switch (preBoard.pieceAt(row,col)) {
                        case CheckersData.RED:
                            g.setColor(Color.RED);
                            g.fillOval(4 + col*20, 4 + row*20, 15, 15);
                            break;
                        case CheckersData.BLACK:
                            g.setColor(Color.BLACK);
                            g.fillOval(4 + col*20, 4 + row*20, 15, 15);
                            break;
                        case CheckersData.RED_KING:
                            g.setColor(Color.RED);
                            g.fillOval(4 + col*20, 4 + row*20, 15, 15);
                            g.setColor(Color.WHITE);
                            g.drawString("K", 7 + col*20, 16 + row*20);
                            break;
                        case CheckersData.BLACK_KING:
                            g.setColor(Color.BLACK);
                            g.fillOval(4 + col*20, 4 + row*20, 15, 15);
                            g.setColor(Color.WHITE);
                            g.drawString("K", 7 + col*20, 16 + row*20);
                            break;
                    }
                }
            }

            if(!moveAI.rows.isEmpty())
            {
            	g.setColor(Color.green);
            	for(int i = 0; i < moveAI.rows.size(); i++)
            	{
            		g.drawRect(2 + moveAI.cols.get(i) * 20, 2 + moveAI.rows.get(i) * 20, 19, 19);
                    g.drawRect(3 + moveAI.cols.get(i) * 20, 3 + moveAI.rows.get(i) * 20, 17, 17);
            	}
            }
            
        }
    }
    
    private class Board extends JPanel implements ActionListener, MouseListener {
        CheckersData board;
        boolean gameInProgress; // Is a game currently in progress?
        int currentPlayer;      // Whose turn is it now?  The possible values
        int selectedRow, selectedCol;  // If the current player has selected a piece to
        List<CheckersMove> legalMoves;  // An array containing the legal moves for the
        AdversarialSearch player_1; // AI player, Alpha-beta
        AdversarialSearch player_2; // MCTS
        CheckersData displayBoard;
        CheckersData agentBoard;
        
        Board() {
            setBackground(Color.BLACK);
            addMouseListener(this);
            resignButton = new JButton("Resign");
            resignButton.addActionListener(this);
            newGameButton = new JButton("New Game");
            newGameButton.addActionListener(this);
            message = new JLabel("",JLabel.CENTER);
            message.setFont(new  Font("Serif", Font.BOLD, 14));
            message.setForeground(Color.green);
            board = new CheckersData();
            //Display board
            displayBoard = new CheckersData();
            agentBoard = new CheckersData();
            //Select the AI players.
            decideAIplayer();
            //Start new game
            doNewGame();
        }

        public void decideAIplayer()
        {
        	Scanner stdin = new Scanner(System.in);
    		boolean done = false;
    		player_1 = new AlphaBetaSearch();
        	player_2 = new MonteCarloTreeSearch();
            while (!done) {
                try {
                	int aikey = stdin.nextInt();
                    if (aikey==1) {done = true; aiKey = 1;}
                    else if(aikey==2)
                    { done =true; aiKey= 2;}
                    else if(aikey==3)
                    {
                    	done =true; aiKey= 3;}
                    else {
                        System.out.println("\tThe entered number should be (1-3)");
                    }
                }
                catch (InputMismatchException e) {
                    System.out.println("\tInvalid input type (must be an integer)");
                    stdin.nextLine();  // Clear invalid input from scanner buffer.
                }
            }
        }

        @Override
        public void actionPerformed(ActionEvent evt) {
            Object src = evt.getSource();
            if (src == newGameButton) {
                doNewGame();
            } else if (src == resignButton) {
                doResign();
            }
        }


        /**
         * Start a new game
         */
        void doNewGame() {
            if (gameInProgress) {
                // This should not be possible, but it doesn't hurt to check.
                message.setText("Finish the current game first!");
                return;
            }
            board.setUpGame();

            displayBoard.setUpGame();
            agentBoard.setUpGame();

            currentPlayer = CheckersData.RED;   // RED moves first.
            player_1.setCheckersData(board);
            player_2.setCheckersData(board);
            legalMoves = board.getLegalMoves(CheckersData.RED);  // Get RED's legal moves.
            selectedRow = -1;   // RED has not yet selected a piece to move.
            message.setText("Red:  Make your move.");
            gameInProgress = true;
            newGameButton.setEnabled(false);
            resignButton.setEnabled(true);

            previous.drawBoard(agentBoard, new CheckersMove());
            repaint();
        }

        void doResign() {
            if (!gameInProgress) {
                message.setText("There is no game in progress!");
                return;
            }
            if (currentPlayer == CheckersData.RED) {
                gameOver("RED resigns.  BLACK wins.");
            } else {
                gameOver("BLACK resigns.  RED wins.");
            }
        }

        void gameOver(String str) {
            message.setText(str);
            newGameButton.setEnabled(true);
            resignButton.setEnabled(false);
            gameInProgress = false;
            //Previous state
            premessage.setText("Game is done");
        }

        void doClickSquare(int row, int col) {

            for (CheckersMove legalMove : legalMoves) {
                if (legalMove.rows.get(0) == row && legalMove.cols.get(0) == col) {
                    selectedRow = row;
                    selectedCol = col;
                    if (currentPlayer == CheckersData.RED) {
                        message.setText("RED:  Make your move.");
                    } else {
                        message.setText("BLACK:  Make your move.");
                    }
                    repaint();
                    return;
                }
            }

            if (selectedRow < 0) {
                message.setText("Click the piece you want to move.");
                return;
            }

            for (CheckersMove legalMove : legalMoves) {
                if (legalMove.rows.get(0) == selectedRow && legalMove.cols.get(0) == selectedCol
                        && legalMove.rows.get(legalMove.rows.size()-1) == row && legalMove.cols.get(legalMove.cols.size()-1) == col) {
                    doMakeMove(legalMove);
                    return;
                }
            }
            message.setText("Click the square you want to move to.");

        }

        void doMakeMove(CheckersMove move) {	
            board.makeMove(move);
            agentBoard=copyBoard(board);
            
            CheckersMove moveAI = new CheckersMove();
            if (currentPlayer == CheckersData.RED) {
                currentPlayer = CheckersData.BLACK;
                legalMoves = board.getLegalMoves(currentPlayer);
                if ((legalMoves == null)||(legalMoves.isEmpty())) {
                    gameOver("BLACK has no moves.  RED wins.");
                    displayBoard = copyBoard(board);
                    previous.drawBoard(board, moveAI);
                    repaint();
                    return;
                } else {
                    message.setText("BLACK:  Now AI's turn.");
                }

                player_1.setCheckersData(board);
                player_2.setCheckersData(board);

                switch (aiKey) {
                    case 1 -> moveAI = player_1.makeMove(legalMoves);
                    case 2 -> moveAI = player_2.makeMove(legalMoves);
                    case 3 -> {
                        Random rand = new Random();
                        if (rand.nextInt(2) == 1) {
                            moveAI = player_1.makeMove(legalMoves);
                        } else {
                            moveAI = player_2.makeMove(legalMoves);
                        }
                    }
                }

                board.makeMove(moveAI);

                displayBoard = copyBoard(board);
                repaint();
            }
            
            previous.drawBoard(agentBoard, moveAI);

            currentPlayer = CheckersData.RED;
            legalMoves = board.getLegalMoves(currentPlayer);
            if ((legalMoves == null)||(legalMoves.isEmpty())) {
                gameOver("RED has no moves.  BLACK wins.");
            } else if (legalMoves.get(0).isJump()) {
                message.setText("RED:  Make your move.  You must jump.");
            } else {
                message.setText("RED:  Make your move.");
            }

            selectedRow = -1;

            if (legalMoves != null) {
                boolean sameStartSquare = true;
                for (int i = 1; i < legalMoves.size(); i++) {
                    if (!Objects.equals(legalMoves.get(i).rows.get(0), legalMoves.get(0).rows.get(0))
                            || legalMoves.get(i).cols.get(0) != legalMoves.get(0).cols.get(0)) {
                        sameStartSquare = false;
                        break;
                    }
                }
                if (sameStartSquare) {
                    selectedRow = legalMoves.get(0).rows.get(0);
                    selectedCol = legalMoves.get(0).cols.get(0);
                }
            }

            repaint();
        }

        @Override
        public void paintComponent(Graphics g) {
            g.setColor(Color.black);
            g.drawRect(0,0,getSize().width-1,getSize().height-1);
            g.drawRect(1,1,getSize().width-3,getSize().height-3);

            /* Draw the squares of the checkerboard and the checkers. */
            for (int row = 0; row < 8; row++) {
                for (int col = 0; col < 8; col++) {
                    if ( row % 2 == col % 2 ) {
                        g.setColor(Color.LIGHT_GRAY);
                    } else {
                        g.setColor(Color.GRAY);
                    }
                    g.fillRect(2 + col*20, 2 + row*20, 20, 20);
                    switch (displayBoard.pieceAt(row,col)) {
                        case CheckersData.RED:
                            g.setColor(Color.RED);
                            g.fillOval(4 + col*20, 4 + row*20, 15, 15);
                            break;
                        case CheckersData.BLACK:
                            g.setColor(Color.BLACK);
                            g.fillOval(4 + col*20, 4 + row*20, 15, 15);
                            break;
                        case CheckersData.RED_KING:
                            g.setColor(Color.RED);
                            g.fillOval(4 + col*20, 4 + row*20, 15, 15);
                            g.setColor(Color.WHITE);
                            g.drawString("K", 7 + col*20, 16 + row*20);
                            break;
                        case CheckersData.BLACK_KING:
                            g.setColor(Color.BLACK);
                            g.fillOval(4 + col*20, 4 + row*20, 15, 15);
                            g.setColor(Color.WHITE);
                            g.drawString("K", 7 + col*20, 16 + row*20);
                            break;
                    }
                }
            }

            if (gameInProgress) {
                g.setColor(Color.cyan);
                for (CheckersMove legalMove : legalMoves) {
                    g.drawRect(2 + legalMove.cols.get(0) * 20, 2 + legalMove.rows.get(0) * 20, 19, 19);
                    g.drawRect(3 + legalMove.cols.get(0) * 20, 3 + legalMove.rows.get(0) * 20, 17, 17);
                }
                if (selectedRow >= 0) {
                    g.setColor(Color.white);
                    g.drawRect(2 + selectedCol*20, 2 + selectedRow*20, 19, 19);
                    g.drawRect(3 + selectedCol*20, 3 + selectedRow*20, 17, 17);
                    g.setColor(Color.green);
                    for (CheckersMove legalMove : legalMoves) {
                        if (legalMove.cols.get(0) == selectedCol && legalMove.rows.get(0) == selectedRow) {
                        	for(int i = 1; i < legalMove.rows.size(); i++ )
                        	{
                        		g.drawRect(2 + legalMove.cols.get(i) * 20, 2 + legalMove.rows.get(i) * 20, 19, 19);
                                g.drawRect(3 + legalMove.cols.get(i) * 20, 3 + legalMove.rows.get(i) * 20, 17, 17);
                        	}
                        	
                        }
                    }
                }
            }

        }

        private CheckersData copyBoard(CheckersData board)
        {
            this.board = board;
            CheckersData newBoard = new CheckersData();
            for(int i=0; i<board.board.length;i++)
            {
                for(int j=0;j<8;j++)
                {
                    newBoard.board[i][j]=board.pieceAt(i, j);
                }
            }
            return newBoard;
        }

        @Override
        public void mousePressed(MouseEvent evt) {
            if (!gameInProgress) {
                message.setText("Click \"New Game\" to start a new game.");
            } else {
                int col = (evt.getX() - 2) / 20;
                int row = (evt.getY() - 2) / 20;
                if (col >= 0 && col < 8 && row >= 0 && row < 8) {
                    doClickSquare(row,col);
                }
            }
        }

        @Override
        public void mouseReleased(MouseEvent evt) { }
        @Override
        public void mouseClicked(MouseEvent evt) { }
        @Override
        public void mouseEntered(MouseEvent evt) { }
        @Override
        public void mouseExited(MouseEvent evt) { }
    }
}
