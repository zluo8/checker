package AiCheckers;

import java.util.List;

public abstract class AdversarialSearch {
    protected CheckersData board;
    protected void setCheckersData(CheckersData board) {
        this.board = board;
    }

    /**
     * 
     * @param legalMoves
     * @return CheckersMove 
     */
    public abstract CheckersMove makeMove(List<CheckersMove> legalMoves);

    public double evaluateBoardUtility(CheckersData checkersData, int player) {
        int countLightPieces = 0;
        int countDarkPieces = 0;
        int countLightKings = 0;
        int countDarkKings = 0;

        for (int i = 0; i < 8; ++i) {
            for (int j = 0; j < 8; ++j) {
                switch (checkersData.board[i][j]) {
                    case CheckersData.RED -> countLightPieces++;
                    case CheckersData.BLACK -> countDarkPieces++;
                    case CheckersData.RED_KING -> countLightKings++;
                    case CheckersData.BLACK_KING -> countDarkKings++;
                }
            }
        }

        if (player == CheckersData.RED) {
            return -(countLightPieces - countDarkPieces - (countLightKings * 0.5 - countDarkKings * 0.5));
        } else {
            return countDarkPieces - countLightPieces + (countDarkKings * 0.5 - countLightKings * 0.5);
        }
    }
}
